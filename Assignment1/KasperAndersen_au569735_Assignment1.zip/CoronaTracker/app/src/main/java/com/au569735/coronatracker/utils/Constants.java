package com.au569735.coronatracker.utils;

public class Constants {

    public static final String STAT_BLOCK = "STAT_BLOCK";
    public static final int REQUEST_EDIT = 101;

}
